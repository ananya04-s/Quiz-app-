# 🧠 Quiz Master — 50 Questions

An AI-powered quiz web app built with **React + Vite**. Pick a genre, and Claude AI instantly generates 50 fresh multiple-choice questions — every play-through is unique.

![React](https://img.shields.io/badge/React-18-61DAFB?style=for-the-badge&logo=react)
![Vite](https://img.shields.io/badge/Vite-5-646CFF?style=for-the-badge&logo=vite)
![Claude AI](https://img.shields.io/badge/Claude-AI-D97706?style=for-the-badge)

---

## ✨ Features

- 🎯 **8 Genres** — Science, History, Geography, Movies, Sports, Music, Technology, Literature
- 🤖 **AI-Generated Questions** — 50 unique questions every time via Claude API
- 📱 **Android Phone UI** — Pixel-perfect phone shell design
- ⏱ **Live Timer** — Tracks time per quiz
- 📊 **Results Screen** — Score, accuracy, time, and grade
- 🔁 **Replay or Switch** — Jump back in instantly

---

## 🚀 Getting Started

### Prerequisites
- Node.js 18+
- An Anthropic API key → https://console.anthropic.com

### Installation

```bash
# 1. Install dependencies
npm install

# 2. Add your API key
#    Open src/App.jsx and find the fetchQuestions() function.
#    The API key is handled via the Anthropic proxy in Claude artifacts,
#    but for local use add your key to the fetch headers:
#
#    headers: {
#      "Content-Type": "application/json",
#      "x-api-key": "YOUR_ANTHROPIC_API_KEY",        ← add this
#      "anthropic-version": "2023-06-01",             ← add this
#      "anthropic-dangerous-direct-browser-calls": "true"  ← add this
#    }

# 3. Run the dev server
npm run dev

# 4. Open http://localhost:5173
```

### Build for production
```bash
npm run build
npm run preview
```

---

## 📂 Project Structure

```
QuizApp50/
├── index.html
├── package.json
├── vite.config.js
├── README.md
└── src/
    ├── main.jsx        ← React entry point
    └── App.jsx         ← Full app (all screens + logic)
```

---

## 🎮 How to Play

1. **Choose a genre** from the 8-tile home screen
2. Wait ~5s while AI generates 50 questions
3. Read each question, pick A/B/C/D, and tap **Submit**
4. Get instant feedback — then tap **Next**
5. See your final **Results** with score, accuracy, and time

---

## 🛠 Tech Stack

| Tool | Purpose |
|------|---------|
| React 18 | UI framework |
| Vite 5 | Build tool / dev server |
| Claude API | AI question generation |
| CSS-in-JS | All styles inline |
| Inter font | Typography (Google Fonts) |

---

## 📄 License

MIT © 2025
